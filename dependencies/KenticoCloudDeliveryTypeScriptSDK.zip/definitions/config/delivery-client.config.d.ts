import { TypeResolver } from '../models/item/type-resolver.class';
export declare class DeliveryClientConfig {
    projectId: string;
    typeResolvers: TypeResolver[];
    options: {
        enableAdvancedLogging?: boolean;
        previewApiKey?: string;
        enablePreviewMode?: boolean;
        defaultLanguage?: string;
    };
    /**
    * Indicates if advanced (developer's) issues are logged in console. Enable for development and disable in production
    */
    enableAdvancedLogging: boolean;
    /**
    * Preview API key used to get unpublished content items
    */
    previewApiKey: string;
    /**
    * Indicates if preview mode is enabled globally
    */
    enablePreviewMode: boolean;
    /**
     * Default content language, can be overidden with languageParameter method
     */
    defaultLanguage: string;
    /**
    * Configuration of Kentico Cloud Delivery client
    * @constructor
    * @param {FieldType} projectId - ProjectId of your Kentico Cloud project
    * @param {TypeResolver[]} typeResolvers - List of resolvers that are used to create strongly typed objects from Kentico Cloud response
    * @param {boolean} enableAdvancedLogging - Indicates if advanced (developer's) issues are logged in console. Enable for development and disable in production.
    * @param {string} previewApiKey - Preview API key used to get unpublished content items
    * @param {boolean} enablePreviewMode - Indicates if preview mode is enabled globally
    * @param {string} defaultLanguage - Sets default language that will be used for all queries unless overriden with query parameters
    */
    constructor(projectId: string, typeResolvers: TypeResolver[], options?: {
        enableAdvancedLogging?: boolean;
        previewApiKey?: string;
        enablePreviewMode?: boolean;
        defaultLanguage?: string;
    });
}

import { Fields } from './field-types';
import { IContentItem } from '../interfaces/item/icontent-item.interface';
export declare class FieldUtilities {
    getUrlSlugProperty(contentItem: IContentItem): Fields.UrlSlugField | null;
}

import { IContentItem } from '../interfaces/item/icontent-item.interface';
import { IItemQueryConfig } from '../interfaces/item/iitem-query.config';
export declare class RichTextResolver {
    private html;
    private modularItems;
    private enableAdvancedLogging;
    private queryConfig;
    /**
    * Type identifying nested modular content in Rich text fields
    */
    private readonly modularContentobjectType;
    /**
     * This tag wil be used instead of 'object'
     */
    private readonly modularContentTagWrapper;
    /**
     * Attribute used to identify modular item based on its codename
     */
    private readonly modularContentCodenameAttributeName;
    /**
     * Tag identifying links
     */
    private readonly linkTag;
    /**
     * Attributes that identifies if of the content item referenced in links
     */
    private readonly linkContentItemIdAttributeName;
    /**
     * Field utilities
     */
    private fieldUtilities;
    /**
    * Rich text resolver
    * @constructor
    * @param {string} html - html to resolve
    * @param {IContentItem} modularItems - modular items
    * @param {boolean} enableAdvancedLogging - Indicates if advanced issues are logged in console
    * @param {IItemQueryConfig} queryConfig - Query configuration
    */
    constructor(html: string, modularItems: IContentItem[], enableAdvancedLogging: boolean, queryConfig: IItemQueryConfig);
    /**
     * Resolves modular content inside the Rich text field.
     * Rich text resolved needs to be configured either on the model or query level
     */
    resolveHtml(): string;
    private processChildNodes(childNodes);
    private processLink(node, attributes);
    private processModularContent(node, attributes);
}

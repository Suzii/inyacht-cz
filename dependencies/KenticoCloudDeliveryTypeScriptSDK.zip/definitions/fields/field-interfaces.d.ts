import { FieldType } from './field-type';
export declare namespace FieldInterfaces {
    interface IField {
        name: string;
        type: FieldType;
        value: any;
        modular_content?: string[];
        taxonomy_group?: string;
    }
    interface IAsset {
        name: string;
        type: string;
        size: number;
        description: string;
        url: string;
    }
    interface IMultipleChoiceOption {
        name: string;
        codename: string;
    }
    interface ITaxonomyTerm {
        name: string;
        codename: string;
    }
}

import { FieldInterfaces } from './field-interfaces';
export declare namespace FieldModels {
    class AssetModel implements FieldInterfaces.IAsset {
        name: string;
        type: string;
        size: number;
        description: string;
        url: string;
        /**
        * Represents Kentico Cloud's asset
        * @constructor
        * @param {string} name - Name of the asset
        * @param {string} type - Type of the asset
        * @param {number} size - Size of the asset
        * @param {string} description - Description of the asset
        * @param {string} url - Url of the asset
        */
        constructor(name: string, type: string, size: number, description: string, url: string);
    }
    class MultipleChoiceOption implements FieldInterfaces.IMultipleChoiceOption {
        name: string;
        codename: string;
        /**
        * Represents Kentico Cloud's multiple choice option
        * @constructor
        * @param {string} name - Name of the option
        * @param {string} codename - Codename of the option
        */
        constructor(name: string, codename: string);
    }
    class TaxonomyTerm implements FieldInterfaces.ITaxonomyTerm {
        name: string;
        codename: string;
        /**
       * Represents taxonomy term
       * @constructor
       * @param {string} name - Name of the taxonomy option
       * @param {string} codename - Codename of the option
       */
        constructor(name: string, codename: string);
    }
    class Parse5Node {
        nodeName: string;
        parentNode: Parse5Node;
        value: string;
        tagName: string;
        childNodes: Parse5Node[];
        attrs: Parse5Attribute[];
        constructor(nodeName: string, parentNode: Parse5Node, value?: string, tagName?: string, childNodes?: Parse5Node[], attrs?: Parse5Attribute[]);
    }
    class Parse5Attribute {
        name: string;
        value: string;
        constructor(name: string, value: string);
    }
}

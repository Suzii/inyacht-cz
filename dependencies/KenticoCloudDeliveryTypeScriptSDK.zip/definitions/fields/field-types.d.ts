import { FieldType } from './field-type';
import { IContentItem } from '../interfaces/item/icontent-item.interface';
import { FieldInterfaces } from './field-interfaces';
import { FieldModels } from './field-models';
import { IItemQueryConfig } from '../interfaces/item/iitem-query.config';
export declare namespace Fields {
    class TextField implements FieldInterfaces.IField {
        name: string;
        value: any;
        /**
        * Text stored in the field
        */
        text: string;
        /**
        * Type of the field
        */
        type: FieldType;
        /**
        * Represents text field of Kentico Cloud item
        * @constructor
        * @param {string} name - Name of the field
        * @param {string} value - Value of the field
        */
        constructor(name: string, value: any);
    }
    class MultipleChoiceField implements FieldInterfaces.IField {
        name: string;
        value: any;
        /**
        * Multiple choice options
        */
        options: FieldModels.MultipleChoiceOption[];
        /**
        * Type of the field
        */
        type: FieldType;
        /**
        * Represents multiple choice field of Kentico Cloud item
        * @constructor
        * @param {string} name - Name of the field
        * @param {string} value - Value of the field
        */
        constructor(name: string, value: any);
    }
    class DateTimeField implements FieldInterfaces.IField {
        name: string;
        value: any;
        /**
        * Date time value
        */
        datetime: Date;
        /**
        * Type of the field
        */
        type: FieldType;
        /**
        * Represents date time field of Kentico Cloud item
        * @constructor
        * @param {string} name - Name of the field
        * @param {string} value - Value of the field
        */
        constructor(name: string, value: any);
    }
    class RichTextField implements FieldInterfaces.IField {
        name: string;
        value: any;
        modularItems: IContentItem[];
        enableAdvancedLogging: boolean;
        itemQueryConfig: IItemQueryConfig;
        /**
        * Type of the field
        */
        type: FieldType;
        /**
         * Resolved html in field - store here once the html was resolved to avoid resolving it multiple times
         */
        private resolvedHtml;
        /**
        * List of modular content items used in this rich text field
        */
        items: IContentItem[];
        /**
        * Represents rich text field of Kentico Cloud item
        * @constructor
        * @param {string} name - Name of the field
        * @param {string} value - Value of the field
        * @param {boolean} enableAdvancedLogging - Indicates if advanced issues are logged in console
        * @param {IItemQueryConfig} itemQueryConfig - Item query config
        */
        constructor(name: string, value: any, modularItems: IContentItem[], enableAdvancedLogging: boolean, itemQueryConfig: IItemQueryConfig);
        getHtml(): string;
    }
    class NumberField implements FieldInterfaces.IField {
        name: string;
        value: any;
        /**
        * Type of the field
        */
        type: FieldType;
        /**
        * Number value of this field
        */
        number: number;
        /**
        * Represents number field of Kentico Cloud item
        * @constructor
        * @param {string} name - Name of the field
        * @param {string} value - Value of the field
        */
        constructor(name: string, value: any);
    }
    class AssetsField implements FieldInterfaces.IField {
        name: string;
        value: any;
        /**
        * Type of the field
        */
        type: FieldType;
        /**
        * List of assets used in this field
        */
        assets: FieldModels.AssetModel[];
        /**
        * Represents asset field of Kentico Cloud item
        * @constructor
        * @param {string} name - Name of the field
        * @param {string} value - Value of the field
        */
        constructor(name: string, value: any);
    }
    class UrlSlugField implements FieldInterfaces.IField {
        name: string;
        value: string;
        contentItem: IContentItem;
        urlSlugResolver: ((contentItem: IContentItem, urlSlug: string) => string) | undefined;
        enableAdvancedLogging: boolean;
        /**
        * Type of the field
        */
        type: FieldType;
        /**
        * Resolved Url of the item
        */
        url: string;
        /**
        * Represents URL slug field of Kentico Cloud item
        * @constructor
        * @param {string} name - Name of the field
        * @param {string} value - Value of the field
        * @param {string} contentItemType - Type of the content item
        * @param {((contentItem: IContentItem, urlSlug: string) => string) | undefined} urlSlugResolver - Callback used to resolve URL slug of the item with type
        * @param {boolean} enableAdvancedLogging - Indicates if advanced issues are logged in console
        */
        constructor(name: string, value: string, contentItem: IContentItem, urlSlugResolver: ((contentItem: IContentItem, urlSlug: string) => string) | undefined, enableAdvancedLogging: boolean);
        private getUrl();
    }
    class TaxonomyField implements FieldInterfaces.IField {
        name: string;
        value: any;
        taxonomyGroup: string | undefined;
        /**
        * Type of the field
        */
        type: FieldType;
        /**
        * List of assigned taxonomy terms
        */
        taxonomyTerms: FieldModels.TaxonomyTerm[];
        /**
        * Represents number field of Kentico Cloud item
        * @constructor
        * @param {string} name - Name of the field
        * @param {string} value - Value of the field
        * @param {string | undefined} taxonomyGroup - Codename of the taxonomy group
        */
        constructor(name: string, value: any, taxonomyGroup: string | undefined);
    }
}

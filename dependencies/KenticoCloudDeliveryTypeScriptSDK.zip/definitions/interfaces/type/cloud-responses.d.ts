import { IContentType } from './icontent-type.interface';
import { IContentTypeSystemAttributes } from './icontent-type-system-attributes.interface';
import { IContentTypeElement } from './icontent-type-element.interface';
import { IPagination } from '../common/ipagination.interface';
export declare namespace CloudTypeResponseInterfaces {
    interface ICloudMultipleTypeResponse {
        types: IContentType[];
        pagination: IPagination;
    }
    interface ICloudSingleTypeResponse {
        system: IContentTypeSystemAttributes;
        elements: IContentTypeElement[];
    }
}

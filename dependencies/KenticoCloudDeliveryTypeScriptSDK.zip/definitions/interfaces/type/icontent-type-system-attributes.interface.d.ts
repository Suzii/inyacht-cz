export interface IContentTypeSystemAttributes {
    id: string;
    name: string;
    codename: string;
    last_modified: Date;
}

export interface IContentTypeElement {
    type: string;
    name: string;
}

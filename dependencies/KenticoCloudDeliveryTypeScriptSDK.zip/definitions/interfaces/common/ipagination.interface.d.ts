export interface IPagination {
    skip: number;
    limit: number;
    count: number;
    next_page: string;
}

export interface IHeader {
    header: string;
    value: string;
}

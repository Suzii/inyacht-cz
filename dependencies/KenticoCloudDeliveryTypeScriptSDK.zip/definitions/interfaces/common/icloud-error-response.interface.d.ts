export interface ICloudErrorResponse {
    message: string;
    request_id: number;
    error_code: number;
    specific_code: number;
}

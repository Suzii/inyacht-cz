export interface IQueryParameter {
    GetParam(): any;
    GetParamValue(): any;
}

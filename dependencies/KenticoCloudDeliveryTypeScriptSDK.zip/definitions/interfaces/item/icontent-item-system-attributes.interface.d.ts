export interface IContentItemSystemAttributes {
    id: string;
    name: string;
    codename: string;
    type: string;
    last_modified: Date;
    language: string;
    sitemap_locations: string[];
}

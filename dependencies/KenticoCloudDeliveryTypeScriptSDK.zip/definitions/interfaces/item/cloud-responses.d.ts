import { IContentItem } from '../../interfaces/item/icontent-item.interface';
import { IModularContent } from '../../interfaces/item/imodular-content.interface';
import { IPagination } from '../../interfaces/common/ipagination.interface';
export declare namespace CloudItemResponseInterfaces {
    interface ICloudResponseMultiple {
        items: IContentItem[];
        modular_content: IModularContent[];
        pagination: IPagination;
    }
    interface ICloudResponseSingle {
        item: IContentItem;
        modular_content: IModularContent[];
    }
}

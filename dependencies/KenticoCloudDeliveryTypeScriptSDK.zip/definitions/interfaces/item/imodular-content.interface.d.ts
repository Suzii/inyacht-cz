import { IContentItemSystemAttributes } from './icontent-item-system-attributes.interface';
export interface IModularContent {
    system: IContentItemSystemAttributes;
    elements: any;
}

import { CloudTypeResponseInterfaces } from '../interfaces/type/cloud-responses';
import { ContentType } from '../models/type/content-type.class';
import { DeliveryClientConfig } from '../config/delivery-client.config';
export declare class TypeMapService {
    private deliveryClientConfig;
    constructor(deliveryClientConfig: DeliveryClientConfig);
    private mapType(type);
    mapSingleType(response: CloudTypeResponseInterfaces.ICloudSingleTypeResponse): ContentType;
    mapMultipleTypes(response: CloudTypeResponseInterfaces.ICloudMultipleTypeResponse): ContentType[];
}

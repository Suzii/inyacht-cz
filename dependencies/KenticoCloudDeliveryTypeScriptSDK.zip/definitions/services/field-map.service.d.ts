import { IContentItem } from '../interfaces/item/icontent-item.interface';
import { DeliveryClientConfig } from '../config/delivery-client.config';
import { IItemQueryConfig } from '../interfaces/item/iitem-query.config';
export declare class FieldMapService {
    private config;
    private typeResolverService;
    private processedItems;
    constructor(config: DeliveryClientConfig);
    /**
     * Maps all fields in given content item and returns strongly typed content item based on the resolver specified
     * in DeliveryClientConfig
     * @param item Item to map (raw response from Kentico Cloud)
     * @param modularContent Modular content sent along with item
     * @param queryConfig Query configuration
     */
    mapFields<TItem extends IContentItem>(item: IContentItem, modularContent: any, queryConfig: IItemQueryConfig): TItem;
    private mapField(field, modularContent, item, queryConfig);
    private mapRichTextField(field, modularContent, queryConfig);
    private mapDateTimeField(field);
    private mapMultipleChoiceField(field);
    private mapNumberField(field);
    private mapTextField(field);
    private mapAssetsField(field);
    private mapTaxonomyField(field);
    private mapUrlSlugField(field, item, queryConfig);
    private mapModularField(field, modularContent, queryConfig);
    private getUrlSlugResolverToUse(item, queryConfig);
}

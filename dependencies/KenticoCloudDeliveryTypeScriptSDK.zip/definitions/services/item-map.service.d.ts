import { IContentItem } from '../interfaces/item/icontent-item.interface';
import { CloudItemResponseInterfaces } from '../interfaces/item/cloud-responses';
import { DeliveryClientConfig } from '../config/delivery-client.config';
import { IItemQueryConfig } from '../interfaces/item/iitem-query.config';
export declare class ItemMapService {
    private config;
    private fieldMapService;
    constructor(config: DeliveryClientConfig);
    private mapItem<TItem>(item, modularContent, queryConfig);
    /**
     * Maps single item to its proper strongly typed model from the given Cloud response
     * @param response Cloud response used to map the item
     * @param queryConfig Query configuration
     */
    mapSingleItem<TItem extends IContentItem>(response: CloudItemResponseInterfaces.ICloudResponseSingle, queryConfig: IItemQueryConfig): TItem;
    /**
    * Maps multiple items to their strongly typed model from the given Cloud response
    * @param response Cloud response used to map the item
    * @param queryConfig Query configuration
    */
    mapMultipleItems<TItem extends IContentItem>(response: CloudItemResponseInterfaces.ICloudResponseMultiple, queryConfig: IItemQueryConfig): TItem[];
}

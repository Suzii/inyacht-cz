import { DeliveryClientConfig } from '../config/delivery-client.config';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/observable/throw';
import { ItemResponses } from '../models/item/responses';
import { IContentItem } from '../interfaces/item/icontent-item.interface';
import { IQueryParameter } from '../interfaces/common/iquery-parameter.interface';
import { TypeResponses } from '../models/type/responses';
import { IItemQueryConfig } from '../interfaces/item/iitem-query.config';
import { IHeader } from '../interfaces/common/iheader.interface';
import { ItemMapService } from '../services/item-map.service';
import { TypeMapService } from '../services/type-map.service';
export declare abstract class QueryService {
    protected config: DeliveryClientConfig;
    /**
    * Base Url to Kentico Delivery API
    */
    private baseDeliveryApiUrl;
    /**
    * Preview url to Kentico Delivery API
    */
    private previewDeliveryApiUrl;
    protected itemMapService: ItemMapService;
    protected typeMapService: TypeMapService;
    constructor(config: DeliveryClientConfig);
    /**
     * Indicates if current query should use preview mode
     * @param queryConfig Query configuration
     */
    private isPreviewModeEnabled(queryConfig);
    /**
     * Gets preview or standard URL based on client and query configuration
     * @param queryConfig Query configuration
     */
    private getDeliveryUrl(queryConfig);
    /**
     * Gets base URL of the request including the project Id
     * @param queryConfig Query configuration
     */
    private getBaseUrl(queryConfig);
    /**
     * Adds query parameters to given url
     * @param url Url to which options will be added
     * @param options Query parameters to add
     */
    private addOptionsToUrl(url, options?);
    protected getUrl(action: string, queryConfig: IItemQueryConfig, options?: IQueryParameter[]): string;
    private handleError(error);
    protected getSingleTypeResponse(json: any): TypeResponses.DeliveryTypeResponse;
    protected getMultipleTypeResponse(json: any, options?: IQueryParameter[]): TypeResponses.DeliveryTypeListingResponse;
    protected getAuthorizationHeader(): IHeader;
    protected getHeadersInternal(queryConfig: IItemQueryConfig): IHeader[];
    protected getHeadersJson(queryConfig: IItemQueryConfig): any;
    protected getSingleResponse<TItem extends IContentItem>(json: any, queryConfig: IItemQueryConfig): ItemResponses.DeliveryItemResponse<TItem>;
    protected getMultipleResponse<TItem extends IContentItem>(json: any, queryConfig: IItemQueryConfig): ItemResponses.DeliveryItemListingResponse<TItem>;
    protected getSingleItem<TItem extends IContentItem>(url: string, queryConfig: IItemQueryConfig): Observable<ItemResponses.DeliveryItemResponse<TItem>>;
    protected getMultipleItems<TItem extends IContentItem>(url: string, queryConfig: IItemQueryConfig): Observable<ItemResponses.DeliveryItemListingResponse<TItem>>;
    protected getSingleType(url: string): Observable<TypeResponses.DeliveryTypeResponse>;
    protected getMultipleTypes(url: string): Observable<TypeResponses.DeliveryTypeListingResponse>;
}

import { IContentItem } from '../interfaces/item/icontent-item.interface';
import { DeliveryClientConfig } from '../config/delivery-client.config';
export declare class TypeResolverService {
    private config;
    constructor(config: DeliveryClientConfig);
    /**
     * Takes given type name and creates a strongly typed model based specified in client configuration
     * @param type Type of the content item
     * @param item Content item
     */
    createTypedObj<TItem extends IContentItem>(type: string, item: IContentItem): TItem;
}

import { DeliveryClientConfig } from '../../config/delivery-client.config';
import { ItemResponses } from '../../models/item/responses';
import { IContentItem } from '../../interfaces/item/icontent-item.interface';
import { SortOrder } from '../../models/common/sort-order.enum';
import { BaseItemQuery } from './base-item-query.class';
import { Observable } from 'rxjs/Rx';
export declare class MultipleItemQuery<TItem extends IContentItem> extends BaseItemQuery<TItem> {
    protected config: DeliveryClientConfig;
    constructor(config: DeliveryClientConfig);
    type(type: string): this;
    equalsFilter(field: string, value: string): this;
    allFilter(field: string, values: string[]): this;
    anyFilter(field: string, values: string[]): this;
    containsFilter(field: string, values: string[]): this;
    greaterThanFilter(field: string, value: string): this;
    greaterThanOrEqualFilter(field: string, value: string): this;
    inFilter(field: string, values: string[]): this;
    lessThanFilter(field: string, value: string): this;
    lessThanOrEqualFilter(field: string, value: string): this;
    rangeFilter(field: string, lowerValue: number, higherValue: number): this;
    limitParameter(limit: number): this;
    orderParameter(field: string, sortOrder: SortOrder): this;
    skipParameter(skip: number): this;
    get(): Observable<ItemResponses.DeliveryItemListingResponse<TItem>>;
    toString(): string;
}

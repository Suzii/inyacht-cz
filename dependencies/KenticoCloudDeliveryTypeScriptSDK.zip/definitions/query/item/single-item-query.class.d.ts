import { DeliveryClientConfig } from '../../config/delivery-client.config';
import { ItemResponses } from '../../models/item/responses';
import { IContentItem } from '../../interfaces/item/icontent-item.interface';
import { BaseItemQuery } from './base-item-query.class';
import { Observable } from 'rxjs/Rx';
export declare class SingleItemQuery<TItem extends IContentItem> extends BaseItemQuery<TItem> {
    protected config: DeliveryClientConfig;
    private codename;
    constructor(config: DeliveryClientConfig, codename: string);
    get(): Observable<ItemResponses.DeliveryItemResponse<TItem>>;
    toString(): string;
}

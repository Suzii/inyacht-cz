import { DeliveryClientConfig } from '../../config/delivery-client.config';
import { ItemResponses } from '../../models/item/responses';
import { IContentItem } from '../../interfaces/item/icontent-item.interface';
import { IQueryParameter } from '../../interfaces/common/iquery-parameter.interface';
import { IItemQueryConfig } from '../../interfaces/item/iitem-query.config';
import { IHeader } from '../../interfaces/common/iheader.interface';
import { BaseQuery } from '../common/base-query.class';
import { Observable } from 'rxjs/Rx';
export declare abstract class BaseItemQuery<TItem extends IContentItem> extends BaseQuery {
    protected config: DeliveryClientConfig;
    protected parameters: IQueryParameter[];
    protected _contentType?: string;
    protected _queryConfig?: IItemQueryConfig;
    constructor(config: DeliveryClientConfig);
    queryConfig(queryConfig: IItemQueryConfig): this;
    getHeaders(): IHeader[];
    languageParameter(languageCodename: string): this;
    elementsParameter(elementCodenames: string[]): this;
    depthParameter(depth: number): this;
    private getQueryConfig();
    protected getMultipleItemsQueryUrl(): string;
    protected getSingleItemQueryUrl(codename: string): string;
    protected runMultipleItemsQuery(): Observable<ItemResponses.DeliveryItemListingResponse<TItem>>;
    protected runSingleItemQuery(codename: string): Observable<ItemResponses.DeliveryItemResponse<TItem>>;
    private processDefaultLanguageParameter();
}

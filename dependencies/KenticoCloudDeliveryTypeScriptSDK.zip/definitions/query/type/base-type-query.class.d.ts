import { DeliveryClientConfig } from '../../config/delivery-client.config';
import { IQueryParameter } from '../../interfaces/common/iquery-parameter.interface';
import { TypeResponses } from '../../models/type/responses';
import { IItemQueryConfig } from '../../interfaces/item/iitem-query.config';
import { BaseQuery } from '../common/base-query.class';
import { Observable } from 'rxjs/Rx';
export declare abstract class BaseTypeQuery extends BaseQuery {
    protected config: DeliveryClientConfig;
    protected parameters: IQueryParameter[];
    protected _queryConfig: IItemQueryConfig;
    constructor(config: DeliveryClientConfig);
    protected getSingleTypeQueryUrl(codename: string): string;
    protected getMultipleTypesQueryUrl(): string;
    protected runMultipleTypesQuery(): Observable<TypeResponses.DeliveryTypeListingResponse>;
    protected runSingleTypeQuery(codename: string): Observable<TypeResponses.DeliveryTypeResponse>;
}

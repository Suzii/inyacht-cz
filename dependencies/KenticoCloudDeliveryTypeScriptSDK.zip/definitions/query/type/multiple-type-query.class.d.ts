import { DeliveryClientConfig } from '../../config/delivery-client.config';
import { TypeResponses } from '../../models/type/responses';
import { BaseTypeQuery } from './base-type-query.class';
import { Observable } from 'rxjs/Rx';
export declare class MultipleTypeQuery extends BaseTypeQuery {
    protected config: DeliveryClientConfig;
    constructor(config: DeliveryClientConfig);
    limitParameter(limit: number): this;
    skipParameter(skip: number): this;
    get(): Observable<TypeResponses.DeliveryTypeListingResponse>;
    toString(): string;
}

import { DeliveryClientConfig } from '../../config/delivery-client.config';
import { TypeResponses } from '../../models/type/responses';
import { BaseTypeQuery } from './base-type-query.class';
import { Observable } from 'rxjs/Rx';
export declare class SingleTypeQuery extends BaseTypeQuery {
    protected config: DeliveryClientConfig;
    private typeCodename;
    constructor(config: DeliveryClientConfig, typeCodename: string);
    get(): Observable<TypeResponses.DeliveryTypeResponse>;
    toString(): string;
}

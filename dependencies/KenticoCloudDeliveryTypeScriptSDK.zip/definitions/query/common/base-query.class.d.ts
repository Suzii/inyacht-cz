import { DeliveryClientConfig } from '../../config/delivery-client.config';
import { QueryService } from '../../services/query.service';
export declare abstract class BaseQuery extends QueryService {
    protected config: DeliveryClientConfig;
    constructor(config: DeliveryClientConfig);
    abstract toString(): string;
    abstract get(): any;
}

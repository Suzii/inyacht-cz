import { IContentType } from '../../interfaces/type/icontent-type.interface';
import { IPagination } from '../../interfaces/common/ipagination.interface';
export declare namespace TypeResponses {
    class DeliveryTypeListingResponse {
        types: IContentType[];
        pagination: IPagination;
        /**
        * Response containing multiple types
        * @constructor
        * @param {IContentType[]} types - Content types
        * @param {IPagination} pagination - Pagination object
        */
        constructor(types: IContentType[], pagination: IPagination);
    }
    class DeliveryTypeResponse {
        type: IContentType;
        /**
        * Response containing single type
        * @constructor
        * @param {IContentType} type - Content type
        */
        constructor(type: IContentType);
    }
}

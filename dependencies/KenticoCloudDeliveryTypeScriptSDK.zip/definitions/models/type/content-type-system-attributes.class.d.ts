import { IContentTypeSystemAttributes } from '../../interfaces/type/icontent-type-system-attributes.interface';
export declare class ContentTypeSystemAttributes implements IContentTypeSystemAttributes {
    id: string;
    name: string;
    codename: string;
    last_modified: Date;
    constructor(id: string, name: string, codename: string, last_modified: Date);
}

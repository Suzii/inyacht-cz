import { IContentType } from '../../interfaces/type/icontent-type.interface';
import { IContentTypeSystemAttributes } from '../../interfaces/type/icontent-type-system-attributes.interface';
import { IContentTypeElement } from '../../interfaces/type/icontent-type-element.interface';
export declare class ContentType implements IContentType {
    system: IContentTypeSystemAttributes;
    elements: IContentTypeElement[];
    constructor(system: IContentTypeSystemAttributes, elements: IContentTypeElement[]);
}

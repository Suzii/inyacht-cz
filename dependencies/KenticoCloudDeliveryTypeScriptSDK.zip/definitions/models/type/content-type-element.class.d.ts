import { IContentTypeElement } from '../../interfaces/type/icontent-type-element.interface';
export declare class ContentTypeElement implements IContentTypeElement {
    type: string;
    name: string;
    constructor(type: string, name: string);
}

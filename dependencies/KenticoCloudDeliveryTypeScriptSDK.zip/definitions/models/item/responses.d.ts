import { IContentItem } from '../../interfaces/item/icontent-item.interface';
import { IPagination } from '../../interfaces/common/ipagination.interface';
export declare namespace ItemResponses {
    class DeliveryItemListingResponse<TItem extends IContentItem> {
        items: TItem[];
        pagination: IPagination;
        /**
         * Indicates if response contains any items
         */
        isEmpty: boolean;
        /**
        * First item or undefined if none is found
        */
        firstItem: TItem;
        /**
        * Last item or undefined if response contains no items
        */
        lastItem: TItem;
        /**
        * Response containing multiple item
        * @constructor
        * @param {TItem[]} items - Collection of content items
        * @param {IPagination} pagination - Pagination object
        */
        constructor(items: TItem[], pagination: IPagination);
        private initIsEmpty();
        private initFirstAndLastItem();
    }
    class DeliveryItemResponse<TItem extends IContentItem> {
        item: TItem;
        /**
         * Indicates if response contains item
         */
        isEmpty: boolean;
        /**
        * Response containing single item
        * @constructor
        * @param {TItem} item - Returned item
        */
        constructor(item: TItem);
        private initIsEmpty();
    }
}

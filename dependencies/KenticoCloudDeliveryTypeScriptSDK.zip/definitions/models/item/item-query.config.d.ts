import { IItemQueryConfig } from '../../interfaces/item/iitem-query.config';
import { IContentItem } from '../../interfaces/item/icontent-item.interface';
export declare class ItemQueryConfig implements IItemQueryConfig {
    /**
    * Callback used to resolve URL slug. This has priority over url slug resolved defined on model level
    */
    urlSlugResolver?: (contentItem: IContentItem, value: string) => string;
    /**
    * Indicates if query should use preview mode. Overrides global settings of Delivery Client
    */
    usePreviewMode?: boolean;
    /**
     * Callback used to resolve modular content nested in Rich text fields to proper HTML
     */
    richTextResolver?: (contentItem: IContentItem) => string;
    /**
    * Configuration of query
    * @constructor
    * @param {(contentItem: IContentItem, value: string) => string} urlSlugResolver - Callback used to resolve URL slug. This has priority over url slug resolved defined on model level
    * @param {boolean} usePreviewMode - Indicates if query should use preview mode. Overrides global settings of Delivery Client
    * @param {<T extends IContentItem>(contentItem: T) => string} richTextResolver?: Callback used to resolve modular content nested in Rich text fields to proper HTML
    */
    constructor(config?: {
        urlSlugResolver?: (contentItem: IContentItem, value: string) => string;
        usePreviewMode?: boolean;
        richTextResolver?: (contentItem: IContentItem) => string;
    });
}

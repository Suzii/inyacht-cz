import { IContentItemSystemAttributes } from '../../interfaces/item/icontent-item-system-attributes.interface';
export declare class ContentItemSystemAttributes implements IContentItemSystemAttributes {
    id: string;
    name: string;
    codename: string;
    type: string;
    last_modified: Date;
    language: string;
    sitemap_locations: string[];
    constructor(id: string, name: string, codename: string, type: string, last_modified: Date, language: string, sitemap_locations: string[]);
}

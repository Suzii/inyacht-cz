import { IHeader } from '../../interfaces/common/iheader.interface';
export declare class Header implements IHeader {
    header: string;
    value: string;
    constructor(header: string, value: string);
}

export declare class CloudError {
    message: string;
    request_id: number;
    error_code: number;
    specific_code: number;
    rawError: any;
    constructor(message: string, request_id: number, error_code: number, specific_code: number, rawError: any);
}

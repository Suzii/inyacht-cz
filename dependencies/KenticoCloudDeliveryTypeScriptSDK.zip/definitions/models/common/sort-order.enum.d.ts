export declare enum SortOrder {
    asc = 0,
    desc = 1,
}

import { IQueryParameter } from '../../interfaces/common/iquery-parameter.interface';
export declare namespace Filters {
    class EqualsFilter implements IQueryParameter {
        field: string;
        value: string;
        constructor(field: string, value: string);
        GetParam(): string;
        GetParamValue(): string | null;
    }
    class AllFilter implements IQueryParameter {
        field: string;
        values: string[];
        constructor(field: string, values: string[]);
        GetParam(): string;
        GetParamValue(): string | null;
    }
    class AnyFilter implements IQueryParameter {
        field: string;
        values: string[];
        constructor(field: string, values: string[]);
        GetParam(): string;
        GetParamValue(): string | null;
    }
    class ContainsFilter implements IQueryParameter {
        field: string;
        values: string[];
        constructor(field: string, values: string[]);
        GetParam(): string;
        GetParamValue(): string | null;
    }
    class GreaterThanFilter implements IQueryParameter {
        field: string;
        value: string;
        constructor(field: string, value: string);
        GetParam(): string;
        GetParamValue(): string | null;
    }
    class GreaterThanOrEqualFilter implements IQueryParameter {
        field: string;
        value: string;
        constructor(field: string, value: string);
        GetParam(): string;
        GetParamValue(): string | null;
    }
    class Infilter implements IQueryParameter {
        field: string;
        values: string[];
        constructor(field: string, values: string[]);
        GetParam(): string;
        GetParamValue(): string | null;
    }
    class LessThanFilter implements IQueryParameter {
        field: string;
        value: string;
        constructor(field: string, value: string);
        GetParam(): string;
        GetParamValue(): string | null;
    }
    class LessThanOrEqualFilter implements IQueryParameter {
        field: string;
        value: string;
        constructor(field: string, value: string);
        GetParam(): string;
        GetParamValue(): string | null;
    }
    class RangeFilter implements IQueryParameter {
        field: string;
        lowerValue: number;
        higherValue: number;
        constructor(field: string, lowerValue: number, higherValue: number);
        GetParam(): string;
        GetParamValue(): string | null;
    }
}

import { IQueryParameter } from '../../interfaces/common/iquery-parameter.interface';
import { SortOrder } from './sort-order.enum';
export declare namespace Parameters {
    class ElementsParameter implements IQueryParameter {
        elementCodenames: string[];
        /**
        * Sets elements (projection) so that only certain elements from a content item are returned
        * @constructor
        * @param {string[]} elementCodenames - Array of element codenames to include in response.
        */
        constructor(elementCodenames: string[]);
        GetParam(): string;
        GetParamValue(): string;
    }
    class LimitParameter implements IQueryParameter {
        limit: number;
        /**
        * Limits the number of items that are returned from response
        * @constructor
        * @param {number} limit - Number of elements that will be returned
        */
        constructor(limit: number);
        GetParam(): string;
        GetParamValue(): string;
    }
    class SkipParameter implements IQueryParameter {
        skip: number;
        /**
        * Configures response to skip certain number of items
        * @constructor
        * @param {number} skip - Number of content items that will be skipped
        */
        constructor(skip: number);
        GetParam(): string;
        GetParamValue(): string;
    }
    class OrderParameter implements IQueryParameter {
        field: string;
        sortOrder: SortOrder;
        /**
        * Sorts the response based on given field.
        * @constructor
        * @param {string} field - Field that will be used for sorting (can be both elements.<fieldname> or system.<fieldname>)
        * @param {SortOrder} sortOrder - Order type (desc/asc). Defaults to 'asc' if SortOrder is null or invalid.
        */
        constructor(field: string, sortOrder: SortOrder);
        GetParam(): string;
        GetParamValue(): string;
    }
    class DepthParameter implements IQueryParameter {
        depth: number;
        /**
        * Configures the depth of the response. Content items might reference modular content items using the Modular content element.
        * Recursively, these modular content items can reference another modular content items.
        * By default, only one level of modular content is returned.
        * @constructor
        * @param {number} depth - Depth fo the response
        */
        constructor(depth: number);
        GetParam(): string;
        GetParamValue(): string;
    }
    class LanguageParameter implements IQueryParameter {
        languageCodename: string;
        /**
        * Specifies language version to fetch
        * @constructor
        * @param {string} languageCodename - Codename of the language
        */
        constructor(languageCodename: string);
        GetParam(): string;
        GetParamValue(): string;
    }
}
